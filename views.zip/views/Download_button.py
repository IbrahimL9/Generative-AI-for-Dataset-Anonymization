import json
import os
from PyQt6.QtWidgets import (
    QWidget, QPushButton, QFileDialog, QLabel, QVBoxLayout
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal

from .Styles import BUTTON_STYLE


class DownloadButton(QWidget):
    """Bouton permettant de charger un ou plusieurs fichiers JSON (via drag & drop ou QFileDialog)."""
    file_loaded = pyqtSignal()

    def __init__(self, text, parent=None):
        super().__init__(parent)
        self.default_text = text
        self.json_data = None

        # Layout vertical pour contenir le bouton et le label
        self.layout = QVBoxLayout(self)
        self.layout.setSpacing(2)
        self.layout.setContentsMargins(0, 0, 0, 0)

        # Bouton
        self.button = QPushButton(text, self)
        self.button.setAcceptDrops(True)
        self.button.setStyleSheet(BUTTON_STYLE)
        self.layout.addWidget(self.button)

        # Label pour afficher les messages
        self.message_label = QLabel("", self)
        self.message_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.message_label.hide()  # caché par défaut
        self.layout.addWidget(self.message_label)

        self.default_size = None

        # Clic sur le bouton = ouvrir le QFileDialog
        self.button.clicked.connect(self.load_file)

        # Permet de recevoir les événements de drag & drop sur le bouton
        self.button.installEventFilter(self)

    def reset(self):
        """Réinitialiser l'état du bouton de téléchargement."""
        self.json_data = None
        self.button.setText(self.default_text)
        self.message_label.hide()

    def showEvent(self, event):
        """Mémoriser la taille initiale du bouton lorsque le widget est affiché."""
        super().showEvent(event)
        self.default_size = self.button.size()

    def eventFilter(self, obj, event):
        """Intercepter les événements de drag & drop sur le bouton."""
        if obj == self.button:
            if event.type() == event.Type.DragEnter:
                self.handleDragEnter(event)
                return True
            elif event.type() == event.Type.DragLeave:
                self.handleDragLeave(event)
                return True
            elif event.type() == event.Type.Drop:
                self.handleDrop(event)
                return True
        return super().eventFilter(obj, event)

    def handleDragEnter(self, event):
        """Si l'utilisateur glisse un .json ou un dossier, on accepte le drop, sinon on ignore."""
        if event.mimeData().hasUrls():
            url = event.mimeData().urls()[0]
            file_path = url.toLocalFile()
            # On n'accepte que les .json ou les dossiers
            if file_path.lower().endswith('.json') or os.path.isdir(file_path):
                # Changer le texte provisoirement
                if os.path.isdir(file_path):
                    self.button.setText("Drop the Folder")
                else:
                    self.button.setText("Drop the File")

                # Agrandir le bouton pour feedback visuel
                if self.default_size:
                    new_width = int(self.default_size.width() * 1.5)
                    new_height = int(self.default_size.height() * 1.5)
                    self.button.setFixedSize(new_width, new_height)

                event.acceptProposedAction()
            else:
                event.ignore()

    def handleDragLeave(self, event):
        """Remettre la taille et le texte par défaut si l'utilisateur quitte la zone de drop."""
        if self.default_size:
            self.button.setFixedSize(self.default_size)
        self.button.setText(self.default_text)
        event.accept()

    def handleDrop(self, event):
        """Quand l'utilisateur dépose un fichier ou un dossier sur le bouton."""
        if event.mimeData().hasUrls():
            url = event.mimeData().urls()[0]
            file_path = url.toLocalFile()

            # Rétablir la taille par défaut
            if self.default_size:
                self.button.setFixedSize(self.default_size)

            # Fichier JSON unique
            if file_path.lower().endswith('.json'):
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        self.json_data = json.load(f)

                    self.button.setText("File loaded !")
                    self.showMessage(
                        f"{os.path.basename(file_path)} has been loaded successfully!",
                        success=True
                    )
                    self.file_loaded.emit()
                    event.acceptProposedAction()
                except Exception as e:
                    self.button.setText("Load error")
                    self.showMessage(
                        f"{os.path.basename(file_path)} failed to load: {e}",
                        success=False
                    )

            # Dossier contenant des JSON
            elif os.path.isdir(file_path):
                concatenated_data = []
                loaded_files = 0
                errors = []

                for entry in os.listdir(file_path):
                    full_path = os.path.join(file_path, entry)
                    if full_path.lower().endswith('.json') and os.path.isfile(full_path):
                        try:
                            with open(full_path, 'r', encoding='utf-8') as f:
                                data = json.load(f)
                            if isinstance(data, list):
                                concatenated_data.extend(data)
                            else:
                                concatenated_data.append(data)
                            loaded_files += 1
                        except Exception as e:
                            errors.append(f"{entry}: {e}")

                if loaded_files > 0:
                    self.json_data = concatenated_data
                    self.button.setText("Folder loaded!")
                    message = (
                        f"{loaded_files} JSON file{'s' if loaded_files > 1 else ''} "
                        f"loaded successfully!"
                    )
                    if errors:
                        message += " Some files failed: " + ", ".join(errors)
                        self.showMessage(message, success=False)
                    else:
                        self.showMessage(message, success=True)

                    self.file_loaded.emit()
                    event.acceptProposedAction()
                else:
                    self.button.setText("Load error")
                    self.showMessage(
                        "No valid JSON files found in the folder.",
                        success=False
                    )
                    event.ignore()
            else:
                # Ni fichier JSON ni dossier
                self.button.setText("Invalid file")
                self.showMessage(
                    "Only JSON files or folders containing JSON files are accepted",
                    success=False
                )
                event.ignore()

    def load_file(self):
        """Ouvre un QFileDialog pour sélectionner un fichier JSON."""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Open JSON File", "", "JSON Files (*.json)"
        )
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    self.json_data = json.load(f)

                self.button.setText("File loaded !")
                self.showMessage(
                    f"{os.path.basename(file_path)} has been loaded successfully",
                    success=True
                )
                self.file_loaded.emit()
            except Exception as e:
                self.button.setText("Load error")
                self.showMessage(
                    f"{os.path.basename(file_path)} failed to load: {e}",
                    success=False
                )
        else:
            # Si l'utilisateur ferme la boîte de dialogue, on remet le texte par défaut
            self.button.setText(self.default_text)

    def showMessage(self, message, success=True):
        """Affiche un message sous le bouton, et le cache après 5s."""
        self.message_label.setText(message)
        if success:
            self.message_label.setStyleSheet(
                "background-color: green; color: white; padding: 5px; border-radius: 3px;"
            )
        else:
            self.message_label.setStyleSheet(
                "background-color: red; color: white; padding: 5px; border-radius: 3px;"
            )
        self.message_label.show()

        # Masquer le message automatiquement après 5 secondes
        QTimer.singleShot(5000, self.message_label.hide)
